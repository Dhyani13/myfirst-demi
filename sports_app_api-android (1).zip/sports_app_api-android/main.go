package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"sports_app_api/internal/config"
	"sports_app_api/internal/database"
	"sports_app_api/internal/firebase"
	"sports_app_api/internal/handlers"
	"sports_app_api/internal/middleware"
	"syscall"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/ulule/limiter/v3"
	"github.com/ulule/limiter/v3/drivers/store/memory"
)

func main() {
	cfg := config.Load()
	gin.SetMode(cfg.GinMode)

	if _, err := database.Initialize(); err != nil {
		log.Fatal("Oh noes! Faiwed to initiawize database T_T:", err)
	}

	if err := firebase.Initialize(); err != nil {
		log.Printf("Warning: Faiwed to initiawize Firebase: %v", err)
		log.Println("Continuing without Firebase suppowt...")
	}

	r := setupRouter(cfg)

	server := &http.Server{
		Addr:           cfg.Host + ":" + cfg.Port,
		Handler:        r,
		ReadTimeout:    cfg.ReadTimeout,
		WriteTimeout:   cfg.WriteTimeout,
		IdleTimeout:    cfg.IdleTimeout,
		MaxHeaderBytes: int(cfg.MaxRequestSize),
	}

	go func() {
		log.Printf("Server stawting on %s:%s, ready for adventuwes! 🚀", cfg.Host, cfg.Port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("wisten: %s\n", err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shhh... Server is getting sweepy... 😴")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := server.Shutdown(ctx); err != nil {
		log.Fatal("Oh noes! Server was forced to sweep T_T:", err)
	}

	log.Println("Server has had a good nap and is exiting. Bye bye! 👋")
}

func setupRouter(cfg *config.Config) *gin.Engine {
	r := gin.New()
	setupMiddleware(r, cfg)

	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "healthy and happy, uwu"})
	})

	api := r.Group("/api/v1")
	{
		auth := api.Group("/auth")
		{
			auth.POST("/register", handlers.Register)
			auth.POST("/login", handlers.Login)
			auth.POST("/refresh", handlers.RefreshToken)
		}

		protected := api.Group("/")
		protected.Use(middleware.FirebaseAuthMiddleware())
		{
			protected.GET("/profile", handlers.GetProfile)
			protected.PUT("/profile", handlers.UpdateProfile)
			protected.POST("/workouts", handlers.CreateWorkout)
			protected.GET("/workouts", handlers.GetWorkouts)
			protected.GET("/workouts/:id", handlers.GetWorkout)
			protected.GET("/stats", handlers.GetStats)
		}
	}
	return r
}

func setupMiddleware(r *gin.Engine, cfg *config.Config) {
	r.Use(gin.Recovery())

	if cfg.EnableRequestLogging {
		r.Use(gin.Logger())
	}

	if cfg.EnableCORS {
		r.Use(cors.New(cors.Config{
			AllowOrigins:     cfg.CORSAllowedOrigins,
			AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
			AllowHeaders:     []string{"Origin", "Content-Type", "Authorization", "Accept"},
			ExposeHeaders:    []string{"Content-Length"},
			AllowCredentials: true,
			MaxAge:           12 * time.Hour,
		}))
	}

	// Rate limiting middleware
	if cfg.EnableRateLimiting {
		store := memory.NewStore()
		rate := limiter.Rate{
			Period: 1 * time.Minute,
			Limit:  int64(cfg.RateLimitRequestsPerMinute),
		}
		instance := limiter.New(store, rate)

		r.Use(func(c *gin.Context) {
			limiterContext, err := instance.Get(c, c.ClientIP())
			if err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "Rate limiter error"})
				c.Abort()
				return
			}

			if limiterContext.Reached {
				c.JSON(http.StatusTooManyRequests, gin.H{"error": "Rate limit exceeded"})
				c.Abort()
				return
			}

			c.Next()
		})
	}
}
