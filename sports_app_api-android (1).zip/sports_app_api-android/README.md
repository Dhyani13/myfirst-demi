<<<<<<< HEAD
# sports_app_api
API for the Sports App "The Lonely One" was working on!
=======
# Sports App API

A RESTful API built with Go and Gin for managing user profiles and workout data for the Sports App.

## Features

- User authentication (JWT-based)
- User profile management (height, weight, nationality, etc.)
- Workout tracking (pushups, shuttle run, endurance run, vertical jump)
- Statistics and analytics
- CORS enabled for Flutter app integration

## Installation

1. Install Go (if not already installed):
   ```bash
   # On macOS with Homebrew
   brew install go
   
   # Or download from https://golang.org/dl/
   ```

2. Install dependencies:
   ```bash
   go mod tidy
   ```

3. Run the server:
   ```bash
   go run main.go
   ```

The API will be available at `http://localhost:8080`

## API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register a new user
- `POST /api/v1/auth/login` - Login user

### User Profile (Protected)
- `GET /api/v1/profile` - Get user profile
- `PUT /api/v1/profile` - Update user profile

### Workouts (Protected)
- `POST /api/v1/workouts` - Create a new workout
- `GET /api/v1/workouts` - Get all user workouts
- `GET /api/v1/workouts/:id` - Get specific workout

### Statistics (Protected)
- `GET /api/v1/stats` - Get user statistics

## Database

Uses SQLite for simplicity. The database file `sports_app.db` will be created automatically.

## Security

- JWT tokens for authentication
- Password hashing with bcrypt
- CORS enabled for Flutter app

## Example Usage

### Register User
```bash
curl -X POST http://localhost:8080/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "height": 175.5,
    "weight": 70.0,
    "nationality": "American",
    "age": 25,
    "gender": "Male"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'
```

### Create Workout
```bash
curl -X POST http://localhost:8080/api/v1/workouts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "type": "pushups",
    "count": 25,
    "duration": 120,
    "calories": 15.5,
    "notes": "Great workout!"
  }'
```
>>>>>>> 05feebd (initial commit)
