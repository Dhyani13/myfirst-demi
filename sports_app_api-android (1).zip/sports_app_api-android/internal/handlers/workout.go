package handlers

import (
	"net/http"
	"sports_app_api/internal/database"
	"sports_app_api/internal/models"
	"strconv" // We need this magical tool!

	"github.com/gin-gonic/gin"
)

// This function is purrfect now!
func CreateWorkout(c *gin.Context) {
	userID := c.GetString("user_id")

	var req models.WorkoutRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	workout := models.Workout{
		UserID:   userID,
		Type:     req.Type,
		Count:    req.Count,
		Duration: req.Duration,
		Calories: req.Calories,
		Notes:    req.Notes,
	}

	if err := database.DB.Create(&workout).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create workout"})
		return
	}

	database.DB.Preload("User").First(&workout, workout.ID)

	c.JSON(http.StatusCreated, gin.H{
		"message": "Workout created successfully, uwu!",
		"workout": workout,
	})
}

// This function is also purrfect!
func GetWorkouts(c *gin.Context) {
	userID := c.GetString("user_id")

	var workouts []models.Workout
	if err := database.DB.Where("user_id = ?", userID).Preload("User").Find(&workouts).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch workouts"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"workouts": workouts})
}

// I fixed this little function for you, master!
func GetWorkout(c *gin.Context) {
	userID := c.GetString("user_id")
	workoutIDStr := c.Param("id")

	// THE FIX: We use our magical strconv tool to turn the text into a number!
	workoutID, err := strconv.Atoi(workoutIDStr)
	if err != nil {
		// If it's not a real number, we send a little frowny-face error!
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid workout ID! Baka!"})
		return
	}

	var workout models.Workout
	// Now our database is super happy because it gets a real number! Yay!
	if err := database.DB.Where("id = ? AND user_id = ?", workoutID, userID).Preload("User").First(&workout).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Workout not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"workout": workout})
}

// This function is a super-genius stats helper!
func GetStats(c *gin.Context) {
	userID := c.GetString("user_id")

	var totalWorkouts int64
	database.DB.Model(&models.Workout{}).Where("user_id = ?", userID).Count(&totalWorkouts)

	var totalPushups int64
	database.DB.Model(&models.Workout{}).Where("user_id = ? AND type = ?", userID, "pushups").Select("COALESCE(SUM(count), 0)").Scan(&totalPushups)

	var totalCalories float64
	database.DB.Model(&models.Workout{}).Where("user_id = ?", userID).Select("COALESCE(SUM(calories), 0)").Scan(&totalCalories)

	var totalDuration int64
	database.DB.Model(&models.Workout{}).Where("user_id = ?", userID).Select("COALESCE(SUM(duration), 0)").Scan(&totalDuration)

	var recentWorkouts []models.Workout
	database.DB.Where("user_id = ? AND created_at >= date('now', '-7 days')", userID).Find(&recentWorkouts)

	var workoutTypes []struct {
		Type  string `json:"type"`
		Count int64  `json:"count"`
	}
	database.DB.Model(&models.Workout{}).Where("user_id = ?", userID).Select("type, COUNT(*) as count").Group("type").Scan(&workoutTypes)

	c.JSON(http.StatusOK, gin.H{
		"total_workouts":  totalWorkouts,
		"total_pushups":   totalPushups,
		"total_calories":  totalCalories,
		"total_duration":  totalDuration,
		"recent_workouts": recentWorkouts,
		"workout_types":   workoutTypes,
	})
}
