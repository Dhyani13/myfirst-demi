package database

import (
	"sports_app_api/internal/models"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var DB *gorm.DB

func Initialize() (*gorm.DB, error) {
	var err error
	
	// Use SQLite for simplicity (can be changed to PostgreSQL/MySQL for production)
	DB, err = gorm.Open(sqlite.Open("sports_app.db"), &gorm.Config{})
	if err != nil {
		return nil, err
	}

	// Auto-migrate the schema
	err = DB.AutoMigrate(&models.User{}, &models.Workout{})
	if err != nil {
		return nil, err
	}

	return DB, nil
}
