package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type User struct {
	ID          string    `json:"id" gorm:"primaryKey"`
	Username    string    `json:"username" gorm:"unique;not null"`
	Email       string    `json:"email" gorm:"unique;not null"`
	Password    string    `json:"-" gorm:"not null"` // Hidden from JSON
	Height      float64   `json:"height"`            // in cm
	Weight      float64   `json:"weight"`            // in kg
	Nationality string    `json:"nationality"`
	Age         int       `json:"age"`
	Gender      string    `json:"gender"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type Workout struct {
	ID          string    `json:"id" gorm:"primaryKey"`
	UserID      string    `json:"user_id" gorm:"not null"`
	Type        string    `json:"type" gorm:"not null"` // pushups, shuttle_run, etc.
	Count       int       `json:"count"`
	Duration    int       `json:"duration"` // in seconds
	Calories    float64   `json:"calories"`
	Notes       string    `json:"notes"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	User        User      `json:"user" gorm:"foreignKey:UserID"`
}

type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type RegisterRequest struct {
	Username    string  `json:"username" binding:"required"`
	Email       string  `json:"email" binding:"required,email"`
	Password    string  `json:"password" binding:"required,min=6"`
	Height      float64 `json:"height"`
	Weight      float64 `json:"weight"`
	Nationality string  `json:"nationality"`
	Age         int     `json:"age"`
	Gender      string  `json:"gender"`
}

type UpdateProfileRequest struct {
	Height      *float64 `json:"height"`
	Weight      *float64 `json:"weight"`
	Nationality *string  `json:"nationality"`
	Age         *int     `json:"age"`
	Gender      *string  `json:"gender"`
}

type WorkoutRequest struct {
	Type     string  `json:"type" binding:"required"`
	Count    int     `json:"count"`
	Duration int     `json:"duration"`
	Calories float64 `json:"calories"`
	Notes    string  `json:"notes"`
}

// BeforeCreate hook to generate UUID
func (u *User) BeforeCreate(tx *gorm.DB) error {
	if u.ID == "" {
		u.ID = uuid.New().String()
	}
	return nil
}

func (w *Workout) BeforeCreate(tx *gorm.DB) error {
	if w.ID == "" {
		w.ID = uuid.New().String()
	}
	return nil
}
